import { useState, useEffect, useMemo, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Phone, 
  MessageSquare, 
  MapPin, 
  Check, 
  Clock, 
  ShieldCheck, 
  ArrowRight, 
  FileText, 
  CreditCard, 
  Printer, 
  Search, 
  Star, 
  User, 
  Calendar, 
  X, 
  Menu, 
  ExternalLink, 
  Mail, 
  Award, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight, 
  Lock, 
  Trash2,
  ThumbsUp,
  FileSpreadsheet,
  Grid,
  TrendingUp,
  CheckSquare
} from "lucide-react";

// Types for Feedback Submission
interface Feedback {
  id: string;
  fullName: string;
  mobile: string;
  email: string;
  subject: string;
  message: string;
  date: string;
}

// Custom Service Interface
interface ServiceItem {
  id: string;
  title: string;
  category: "banking" | "aadhaar" | "govt_schemes" | "forms" | "printing";
  description: string;
  highlights?: string[];
  isPopular?: boolean;
  icon: string;
}

export default function App() {
  // Navigation & UI States
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);

  // Carousel State
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);

  // Form & Lead Management States
  const [feedbackList, setFeedbackList] = useState<Feedback[]>([]);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    mobile: "",
    email: "",
    subject: "",
    message: ""
  });
  
  // Admin Portal States
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [adminAccessGranted, setAdminAccessGranted] = useState(false);
  const [adminError, setAdminError] = useState("");

  // Image Assets presence check
  const [bannerExists, setBannerExists] = useState(true);
  const [ownerPhotoExists, setOwnerPhotoExists] = useState(true);
  const [heroRightPanelTab, setHeroRightPanelTab] = useState<"banner" | "terminal">("banner");

  // Modal States
  const [activeModal, setActiveModal] = useState<"privacy" | "terms" | "disclaimer" | null>(null);

  // Working Hours Live Status calculation
  const [isOpenNow, setIsOpenNow] = useState(true);
  const [currentTimeStr, setCurrentTimeStr] = useState("");

  // Services Dataset
  const services: ServiceItem[] = useMemo(() => [
    {
      id: "aeps_withdrawal",
      title: "AEPS Cash Withdrawal",
      category: "banking",
      description: "Fast, secure, biometric-enabled cash withdrawal directly using your Aadhaar-linked bank account. No ATM card required.",
      highlights: ["Instant Settlement", "Biometric Validation", "Zero Card Fees"],
      isPopular: true,
      icon: "banking"
    },
    {
      id: "money_transfer",
      title: "Money Transfer (DMT)",
      category: "banking",
      description: "Instant Domestic Money Transfer (DMT) to any bank account in India, 24/7. Trusted IMPS technology.",
      highlights: ["Immediate Receipt", "Secure PIN Entry", "All Banks Covered"],
      isPopular: true,
      icon: "transfer"
    },
    {
      id: "aadhaar_download",
      title: "Aadhaar Download Only",
      category: "aadhaar",
      description: "Authorized download and high-quality card printing of your official E-Aadhaar. Highly secure and private.",
      highlights: ["Official PDF Retrieval", "Instant High-DPI Print", "Data Purged Post-Print"],
      isPopular: false,
      icon: "aadhaar"
    },
    {
      id: "pan_new",
      title: "New PAN Card Application",
      category: "forms",
      description: "Official application processing for new Permanent Account Number (PAN) cards for individuals, minors, and businesses.",
      highlights: ["Form 49A Processing", "Document Verification", "e-PAN in 3 Days"],
      isPopular: true,
      icon: "pan"
    },
    {
      id: "pan_correction",
      title: "PAN Related Corrections",
      category: "forms",
      description: "Correction of name, date of birth, photograph, signature or address in your existing PAN card database.",
      highlights: ["Correction Form Processing", "Name Change Support", "Reprint Dispatch"],
      isPopular: false,
      icon: "pan_edit"
    },
    {
      id: "ayushman_bharat",
      title: "Ayushman Bharat Card",
      category: "govt_schemes",
      description: "Register and print your PM-JAY Ayushman Bharat card to avail up to ₹5 Lakhs free healthcare coverage per family annually.",
      highlights: ["Scheme Eligibility Check", "E-KYC Setup", "Premium Card Print"],
      isPopular: true,
      icon: "scheme"
    },
    {
      id: "pm_kisan",
      title: "PM Kisan Services",
      category: "govt_schemes",
      description: "Complete support for PM Kisan Samman Nidhi Yojana registrations, beneficiary status check, and biometric e-KYC updates.",
      highlights: ["New Farmer Registry", "E-KYC Renewal", "Installment Status Tracker"],
      isPopular: false,
      icon: "farmer"
    },
    {
      id: "scholarship_forms",
      title: "Scholarship & Exam Forms",
      category: "forms",
      description: "Accurate filing for Mahadbt, national, and university-level scholarships. Minimizes errors to ensure processing.",
      highlights: ["No-Error Document Upload", "Print Confirmation", "Track Status Logs"],
      isPopular: false,
      icon: "scholarship"
    },
    {
      id: "xerox_print",
      title: "High-Speed Xerox & Printing",
      category: "printing",
      description: "Premium black & white and crisp high-speed colour laser printing, photocopying, and bulk document scanning.",
      highlights: ["Crisp Laser Quality", "Heavy-GSM Paper Option", "Bulk Scanning to PDF"],
      isPopular: false,
      icon: "print"
    },
    {
      id: "lamination_photo",
      title: "Passport Photos & Lamination",
      category: "printing",
      description: "Instant high-gloss passport size photographs with neutral backgrounds. Protective thermal lamination for vital certificates.",
      highlights: ["Matte/Glossy Finish", "8-Pack Instant Prints", "Heavy Duty Lamination Shield"],
      isPopular: false,
      icon: "camera"
    },
    {
      id: "recharge_utility",
      title: "Mobile & DTH Recharge / Utility Bills",
      category: "forms",
      description: "Instant mobile recharges, DTH package plans, and prompt utility bill payments (Electricity, Water, Gas, Landline).",
      highlights: ["All Operators Supported", "Official Digital Receipts", "Instant Confirmation"],
      isPopular: false,
      icon: "utility"
    }
  ], []);

  // Customer Testimonials Array
  const reviews = [
    {
      name: "Rahul Patil",
      role: "Citizen, Vaijali",
      rating: 5,
      text: "Very good CSC center. I visited for AEPS cash withdrawal and the service was quick and secure. The staff is polite and helpful. Highly recommended.",
      date: "1 week ago"
    },
    {
      name: "Sneha Pawar",
      role: "Resident, Shahada",
      rating: 5,
      text: "I applied for my PAN Card here and the process was very smooth. They explained everything clearly and completed the work on time. Excellent service.",
      date: "2 weeks ago"
    },
    {
      name: "Ganesh Thakare",
      role: "Farmer, Vaijali",
      rating: 5,
      text: "Best place for online form filling and government services. I also use their printing and Xerox services regularly. Fast and reliable.",
      date: "3 weeks ago"
    },
    {
      name: "Priya Shinde",
      role: "Visitor, Shahada",
      rating: 5,
      text: "I visited this CSC center for Aadhaar download and mobile recharge. The service was quick, affordable, and professional. I will definitely visit again.",
      date: "1 month ago"
    },
    {
      name: "Mahesh More",
      role: "Resident, Vaijali",
      rating: 5,
      text: "Very trustworthy CSC center in Vaijali. AEPS withdrawal, banking services, and document printing are all available at one place. Great customer support.",
      date: "1 month ago"
    }
  ];

  // Scroll effect for sticky navbar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Auto playing reviews carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentReviewIndex((prev) => (prev + 1) % reviews.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [reviews.length]);

  // Load Feedback Submissions from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem("csc_feedback_logs");
    if (stored) {
      try {
        setFeedbackList(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse feedback logs", e);
      }
    } else {
      // Seed with 2 dummy logs to show the interface if admin checks it
      const initialFeedback: Feedback[] = [
        {
          id: "seed-1",
          fullName: "Ganesh Choudhary",
          mobile: "9422019283",
          email: "ganesh.ch@gmail.com",
          subject: "Enquiry about Ayushman Card documents",
          message: "Namaskar Tai, I want to know which documents are required for registering my grandmother for the Ayushman Bharat scheme. I will visit tomorrow.",
          date: new Date(Date.now() - 24 * 60 * 60 * 1000).toLocaleString()
        },
        {
          id: "seed-2",
          fullName: "Savita Jadhav",
          mobile: "9834190821",
          email: "savitajadhav@yahoo.com",
          subject: "Excellent Service feedback",
          message: "Thank you for helping me download my Aadhaar card so quickly. It was urgent for my bank account linking.",
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toLocaleString()
        }
      ];
      setFeedbackList(initialFeedback);
      localStorage.setItem("csc_feedback_logs", JSON.stringify(initialFeedback));
    }

    // Dynamic Live Working Hours calculation
    const checkOpenStatus = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = { 
        timeZone: "Asia/Kolkata", 
        hour: "numeric", 
        minute: "numeric", 
        hour12: true, 
        weekday: "long" 
      };
      
      try {
        const kolkataTimeStr = now.toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
        const kolkataDate = new Date(kolkataTimeStr);
        const day = kolkataDate.getDay(); // 0 is Sunday, 1 is Monday, etc.
        const hour = kolkataDate.getHours();
        const minute = kolkataDate.getMinutes();
        const totalMinutes = hour * 60 + minute;

        // Mon-Sun: 9 AM (540 min) to 7 PM (1140 min)
        if (totalMinutes >= 540 && totalMinutes < 1140) {
          setIsOpenNow(true);
        } else {
          setIsOpenNow(false);
        }

        // Format nice display string for current local time
        const formattedTime = kolkataDate.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true
        });
        const weekdayStr = kolkataDate.toLocaleDateString("en-US", { weekday: "long" });
        setCurrentTimeStr(`${weekdayStr}, ${formattedTime} (IST)`);
      } catch (err) {
        // Fallback to local machine time if timeZone lookup fails
        const hour = now.getHours();
        if (hour >= 9 && hour < 19) {
          setIsOpenNow(true);
        } else {
          setIsOpenNow(false);
        }
        setCurrentTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      }
    };

    checkOpenStatus();
    const statusInterval = setInterval(checkOpenStatus, 30000); // update every 30s
    return () => clearInterval(statusInterval);
  }, []);

  // Check for uploaded images presence
  useEffect(() => {
    const checkAssets = async () => {
      try {
        const bRes = await fetch("/banner.jpg", { method: "HEAD" });
        if (bRes.ok) setBannerExists(true);
      } catch (e) {
        console.log("No custom banner.jpg found on server yet.");
      }
      try {
        const oRes = await fetch("/owner.jpg", { method: "HEAD" });
        if (oRes.ok) setOwnerPhotoExists(true);
      } catch (e) {
        console.log("No custom owner.jpg found on server yet.");
      }
    };
    checkAssets();
  }, []);

  // Filter and Search Services Logic
  const filteredServices = useMemo(() => {
    return services.filter((service) => {
      const matchesCategory = activeTab === "all" || service.category === activeTab;
      const matchesSearch = 
        service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        service.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (service.highlights && service.highlights.some(h => h.toLowerCase().includes(searchQuery.toLowerCase())));
      return matchesCategory && matchesSearch;
    });
  }, [services, activeTab, searchQuery]);

  // Form submission handler
  const handleFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.mobile) {
      alert("Please provide at least your Name and Mobile Number.");
      return;
    }

    const newFeedback: Feedback = {
      id: `fb-${Date.now()}`,
      fullName: formData.fullName,
      mobile: formData.mobile,
      email: formData.email || "N/A",
      subject: formData.subject || "General Enquiry",
      message: formData.message,
      date: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) + " (IST)"
    };

    const updated = [newFeedback, ...feedbackList];
    setFeedbackList(updated);
    localStorage.setItem("csc_feedback_logs", JSON.stringify(updated));
    setFormSubmitted(true);

    // Form submission action - also generate custom mailto link to send to owner's email
    const emailSubject = encodeURIComponent(`[CSC Website] Inquiry from ${formData.fullName}`);
    const emailBody = encodeURIComponent(
      `Name: ${formData.fullName}\n` +
      `Mobile: ${formData.mobile}\n` +
      `Email: ${formData.email}\n` +
      `Subject: ${formData.subject}\n` +
      `Message: ${formData.message}\n\n` +
      `Submitted on: ${newFeedback.date}`
    );
    
    // Automatically present draft composition link for user convenience 
    const mailtoLink = `mailto:travelways000@gmail.com?subject=${emailSubject}&body=${emailBody}`;
    
    // Silent execution trace/trigger. For preview safety we don't open full external popups spontaneously
    console.log("Form successfully logged to localStorage! Mailto link: ", mailtoLink);
  };

  // Reset Contact Form
  const resetForm = () => {
    setFormData({
      fullName: "",
      mobile: "",
      email: "",
      subject: "",
      message: ""
    });
    setFormSubmitted(false);
  };

  // Authenticate Admin Access to feedback messages
  const handleAdminAuth = (e: FormEvent) => {
    e.preventDefault();
    if (adminPassword === "9823473232") {
      setAdminAccessGranted(true);
      setAdminError("");
    } else {
      setAdminError("Incorrect PIN. Access Denied.");
    }
  };

  // Delete feedback item
  const deleteFeedback = (id: string) => {
    const filtered = feedbackList.filter(item => item.id !== id);
    setFeedbackList(filtered);
    localStorage.setItem("csc_feedback_logs", JSON.stringify(filtered));
  };

  // Custom function to return service icons or emojis
  const renderServiceIcon = (iconName: string) => {
    switch (iconName) {
      case "banking":
        return (
          <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600">
            <CreditCard className="w-6 h-6" />
          </div>
        );
      case "transfer":
        return (
          <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center text-green-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        );
      case "aadhaar":
        return (
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600">
            <ShieldCheck className="w-6 h-6" />
          </div>
        );
      case "pan":
        return (
          <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600">
            <FileText className="w-6 h-6" />
          </div>
        );
      case "pan_edit":
        return (
          <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center text-red-600">
            <CheckSquare className="w-6 h-6" />
          </div>
        );
      case "scheme":
        return (
          <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center text-purple-600">
            <Award className="w-6 h-6" />
          </div>
        );
      case "farmer":
        return (
          <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600">
            <Grid className="w-6 h-6" />
          </div>
        );
      case "scholarship":
        return (
          <div className="w-12 h-12 rounded-xl bg-sky-100 flex items-center justify-center text-sky-600">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
        );
      case "print":
        return (
          <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
            <Printer className="w-6 h-6" />
          </div>
        );
      case "camera":
        return (
          <div className="w-12 h-12 rounded-xl bg-teal-100 flex items-center justify-center text-teal-600">
            <User className="w-6 h-6" />
          </div>
        );
      case "utility":
        return (
          <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        );
      default:
        return (
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
            <FileText className="w-6 h-6" />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-blue-600 selection:text-white bg-[#F8FAFC]">
      
      {/* 1. SCROLLING NOTIFICATION ALERT BANNER */}
      <div className="bg-blue-900 text-white text-xs md:text-sm py-2 px-4 font-medium border-b border-blue-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="inline-flex items-center justify-center bg-orange-500 text-white font-extrabold px-2 py-0.5 rounded text-[10px] animate-pulse tracking-wide shrink-0">
              OFFICIAL BANNER
            </span>
            <p className="truncate text-blue-100 animate-fade-in">
              🇮🇳 Government Authorized CSC Center | Direct AEPS Bank Withdrawals & Official E-Aadhaar Prints
            </p>
          </div>
          <div className="flex items-center gap-4 shrink-0 text-xs text-blue-200">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-orange-400" />
              IST: {currentTimeStr || "9:00 AM - 7:00 PM"}
            </span>
            <span className="hidden md:inline">|</span>
            <span className={`inline-flex items-center gap-1 font-semibold ${isOpenNow ? "text-green-400" : "text-red-400"}`}>
              <span className={`w-2 h-2 rounded-full ${isOpenNow ? "bg-green-400 animate-ping" : "bg-red-400"}`}></span>
              {isOpenNow ? "OPEN NOW" : "CLOSED NOW"}
            </span>
          </div>
        </div>
      </div>

      {/* 2. STICKY HEADER & NAVIGATION */}
      <header className={`sticky top-0 z-50 transition-all duration-300 border-b ${
        scrolled 
          ? "bg-white/95 backdrop-blur shadow-md py-3 border-slate-200" 
          : "bg-white py-4 border-slate-100"
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo & Branding */}
          <a href="#home" id="nav-brand-logo" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-blue-900 to-blue-700 flex items-center justify-center text-white shadow-md border-2 border-orange-400/30 transition-transform group-hover:scale-105">
              {/* CSC Inspired Sharp Emblem Vector */}
              <svg viewBox="0 0 100 100" className="w-6 h-6 fill-current">
                <path d="M50,10 L90,30 L90,70 L50,90 L10,70 L10,30 Z" className="opacity-20" />
                <path d="M50,20 L80,35 L80,65 L50,80 L20,65 L20,35 Z" fill="#F97316" />
                <circle cx="50" cy="50" r="18" fill="#FFFFFF" />
                <circle cx="50" cy="50" r="10" fill="#1E3A8A" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-extrabold font-display text-blue-900 leading-none tracking-tight">
                Shri Swami Samarth <span className="text-orange-500 font-black">CSC</span>
              </h1>
              <p className="text-[10px] md:text-xs font-bold tracking-wider text-slate-500 uppercase">
                Digital Seva & Banking Portal
              </p>
              <p className="text-[9px] md:text-[10px] font-extrabold text-orange-600 mt-0.5 leading-none">
                "आपले सरकार, आपली सेवा - सदैव आपल्या सेवेत" 🚩
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
            <a href="#about" id="nav-link-about" className="hover:text-blue-900 transition-colors py-1.5 border-b-2 border-transparent hover:border-blue-900">About Us</a>
            <a href="#services" id="nav-link-services" className="hover:text-blue-900 transition-colors py-1.5 border-b-2 border-transparent hover:border-blue-900">Our Services</a>
            <a href="#features" id="nav-link-why" className="hover:text-blue-900 transition-colors py-1.5 border-b-2 border-transparent hover:border-blue-900">Why Choose Us</a>
            <a href="#contact" id="nav-link-contact" className="hover:text-blue-900 transition-colors py-1.5 border-b-2 border-transparent hover:border-blue-900">Contact & Map</a>
          </nav>

          {/* Desktop Call CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            <a 
              href="tel:9324720948" 
              id="header-call-btn"
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-blue-900 font-bold py-2 px-4 rounded-xl text-xs transition-all border border-slate-200"
            >
              <Phone className="w-3.5 h-3.5 text-blue-800" />
              9324720948
            </a>
            <a 
              href="https://wa.me/919324720948?text=Hello%20Shri%20Swami%20Samarth%20CSC%20Center,%20I%20have%20an%20enquiry." 
              target="_blank" 
              rel="noopener noreferrer"
              id="header-whatsapp-btn"
              className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl text-xs shadow-md transition-all"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-current" />
              WhatsApp Us
            </a>
          </div>

          {/* Mobile Hamburguer Toggle */}
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-lg bg-slate-100 text-slate-800 focus:outline-none"
            aria-label="Toggle navigation menu"
            id="mobile-menu-toggle"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100 py-4 px-6 space-y-4 shadow-inner">
            <div className="flex flex-col gap-3 font-semibold text-slate-700 text-base">
              <a 
                href="#about" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="hover:text-blue-900 py-1"
              >
                About Us
              </a>
              <a 
                href="#services" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="hover:text-blue-900 py-1"
              >
                Our Services
              </a>
              <a 
                href="#features" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="hover:text-blue-900 py-1"
              >
                Why Choose Us
              </a>
              <a 
                href="#contact" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="hover:text-blue-900 py-1"
              >
                Contact & Map
              </a>
            </div>
            <hr className="border-slate-100" />
            <div className="grid grid-cols-2 gap-3 pt-1">
              <a 
                href="tel:9324720948"
                className="flex items-center justify-center gap-2 bg-slate-100 text-blue-900 text-sm font-bold py-2.5 rounded-xl border border-slate-200"
              >
                <Phone className="w-4 h-4" />
                Call Now
              </a>
              <a 
                href="https://wa.me/919324720948?text=Hello%20Shri%20Swami%20Samarth%20CSC%20Center,%20I%20have%20an%20enquiry." 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-green-600 text-white text-sm font-bold py-2.5 rounded-xl shadow"
              >
                <MessageSquare className="w-4 h-4 fill-current" />
                WhatsApp
              </a>
            </div>
          </div>
        )}
      </header>

      {/* 3. HERO BANNER SECTION */}
      <section id="home" className="relative bg-gradient-to-br from-blue-950 via-blue-900 to-indigo-900 text-white overflow-hidden py-16 lg:py-24">
        {/* Subtle Decorative Geometric Background Grids */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-500/20 via-transparent to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:32px_32px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-400/20 text-blue-300 text-xs sm:text-sm font-semibold tracking-wide">
                <Award className="w-4 h-4 text-orange-400" />
                <span>Government Registered CSC: 2022</span>
              </div>
              
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black font-display tracking-tight leading-tight">
                Shri Swami Samarth <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-300 to-orange-400">
                  CSC Center
                </span>
              </h2>

              <p className="text-blue-200 text-base sm:text-lg lg:text-xl font-medium max-w-2xl">
                "Your Trusted Digital Service Partner for Government & Banking Services." Fast biometric withdrawals, secure transfers, document filings, and official digital schemes in Vaijali.
              </p>

              {/* Badges bar */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-3 backdrop-blur-sm">
                  <ShieldCheck className="w-5 h-5 text-green-400 shrink-0" />
                  <div>
                    <p className="text-[10px] uppercase text-blue-300 font-bold tracking-wider">AEPS Network</p>
                    <p className="text-xs font-bold text-white">100% Secure Auth</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-3 backdrop-blur-sm">
                  <Award className="w-5 h-5 text-amber-400 shrink-0" />
                  <div>
                    <p className="text-[10px] uppercase text-blue-300 font-bold tracking-wider">Experience</p>
                    <p className="text-xs font-bold text-white">4+ Years of Service</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-3 backdrop-blur-sm col-span-2 sm:col-span-1">
                  <MapPin className="w-5 h-5 text-orange-400 shrink-0" />
                  <div>
                    <p className="text-[10px] uppercase text-blue-300 font-bold tracking-wider">Location</p>
                    <p className="text-xs font-bold text-white">Vaijali, Shahada</p>
                  </div>
                </div>
              </div>

              {/* Call to Actions Stack */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <a 
                  href="https://wa.me/919324720948?text=Hello%20Shri%20Swami%20Samarth%20CSC%20Center,%20I%20am%20enquiring%20about%20your%20digital%20services." 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-lg hover:shadow-green-900/20 transition-all text-sm group"
                  id="hero-whatsapp"
                >
                  <MessageSquare className="w-5 h-5 fill-current" />
                  Contact on WhatsApp
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </a>
                
                <a 
                  href="tel:9324720948"
                  className="flex items-center justify-center gap-2 bg-white hover:bg-slate-100 text-blue-900 font-extrabold px-6 py-3.5 rounded-2xl shadow-md transition-all text-sm"
                  id="hero-call"
                >
                  <Phone className="w-5 h-5 text-blue-800" />
                  Call Now
                </a>

                <a 
                  href="https://www.google.com/maps/search/?api=1&query=H9G7%2BJ2X+Vaijaly+Maharashtra"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-blue-800/80 hover:bg-blue-800 text-blue-200 hover:text-white font-extrabold px-5 py-3.5 rounded-2xl border border-blue-700 transition-all text-sm"
                  id="hero-directions"
                >
                  <MapPin className="w-4 h-4 text-orange-400" />
                  Get Directions
                </a>
              </div>
            </div>

            {/* Right Interactive Display Column */}
            <div className="lg:col-span-5 relative">
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-orange-500 to-blue-500 opacity-20 blur-lg" />
              
              <div className="relative bg-slate-900 border border-slate-700/60 rounded-3xl p-5 shadow-2xl backdrop-blur">
                
                {/* Segmented Controller Tab Headers */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                  <div className="flex gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    <button
                      onClick={() => setHeroRightPanelTab("banner")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        heroRightPanelTab === "banner"
                          ? "bg-blue-600 text-white shadow-md"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      Storefront Banner
                    </button>
                    <button
                      onClick={() => setHeroRightPanelTab("terminal")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        heroRightPanelTab === "terminal"
                          ? "bg-blue-600 text-white shadow-md"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      System Terminal
                    </button>
                  </div>
                  <span className="text-[10px] text-green-400 font-mono tracking-wider bg-green-500/10 px-2 py-0.5 rounded border border-green-500/20">
                    ONLINE
                  </span>
                </div>

                <AnimatePresence mode="wait">
                  {heroRightPanelTab === "banner" ? (
                    <motion.div
                      key="banner-tab"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-3"
                    >
                      {bannerExists ? (
                        <div className="rounded-2xl overflow-hidden border border-slate-700 shadow-inner bg-slate-950">
                          <img
                            src="/banner.jpg"
                            alt="Swami Samarth CSC Storefront Banner"
                            className="w-full h-auto object-cover"
                            onError={() => setBannerExists(false)}
                          />
                        </div>
                      ) : (
                        /* HIGH FIDELITY DIGITAL REPRESENTATION OF THE USER'S STREET BANNER */
                        <div className="bg-sky-100 rounded-2xl p-4 border-2 border-orange-500/30 shadow-inner text-slate-800 font-sans relative overflow-hidden select-none">
                          {/* Inner container with realistic board shadow */}
                          <div className="bg-sky-50 border border-sky-200/60 p-3 rounded-xl flex flex-col space-y-2.5">
                            
                            {/* Logo Row matching MSRLM, Maharashtra State, and CSC */}
                            <div className="flex items-center justify-between border-b border-sky-200/50 pb-2">
                              {/* Left Logo: Umed */}
                              <div className="flex flex-col items-center">
                                <div className="w-7 h-7 rounded-full bg-red-600 flex items-center justify-center text-white text-[10px] font-bold shadow-sm">
                                  ✋
                                </div>
                                <span className="text-[8px] font-black text-red-600 leading-none mt-0.5">उमेद</span>
                              </div>
                              {/* Center Emblem Text */}
                              <div className="text-center">
                                <span className="text-[8px] font-extrabold text-blue-900 block">महाराष्ट्र शासन</span>
                                <div className="w-3.5 h-3.5 mx-auto my-0.5 bg-blue-900 rounded-full flex items-center justify-center text-white text-[6px]">☸</div>
                              </div>
                              {/* Right Logo: CSC */}
                              <div className="flex flex-col items-center">
                                <div className="bg-blue-900 text-white font-extrabold px-1.5 py-0.5 text-[9px] rounded shadow-sm leading-none border border-blue-700">
                                  CSC
                                </div>
                                <span className="text-[6px] text-slate-400 mt-0.5 leading-none">e-Governance</span>
                              </div>
                            </div>

                            {/* Campaign Text Banner */}
                            <div className="text-center bg-sky-200/40 rounded-md py-1 border border-sky-300/30">
                              <p className="text-[8px] font-black text-blue-900 tracking-wide uppercase">
                                महाराष्ट्र राज्य ग्रामीण जीवनोन्नती अभियान (MSRLM)
                              </p>
                              <p className="text-[7px] font-bold text-slate-600 leading-none">
                                (ग्रामविकास विभाग - महाराष्ट्र शासन)
                              </p>
                            </div>

                            {/* Main Center Title: Grahak Seva Kendra */}
                            <div className="text-center py-1">
                              <h3 className="text-xl sm:text-2xl font-black text-blue-900 leading-none font-display tracking-wide drop-shadow-sm">
                                ग्राहक सेवा केंद्र
                              </h3>
                            </div>

                            {/* Red High-Impact Focus Strip */}
                            <div className="bg-red-600 text-white text-center py-2 px-3 rounded-lg shadow-md border border-red-500 animate-pulse">
                              <p className="text-xs sm:text-sm font-black tracking-wide leading-none flex items-center justify-center gap-1.5">
                                <span className="text-base leading-none">🔍</span>
                                आधार कार्ड वरून पैसे काढणे व भरणे
                              </p>
                            </div>

                            {/* bullet key services */}
                            <div className="bg-white/80 rounded-lg p-2.5 border border-sky-200/50">
                              <ul className="text-xs font-bold text-blue-950 space-y-1.5 text-left pl-2">
                                <li className="flex items-center gap-2">
                                  <span className="text-red-500 text-sm">✴</span>
                                  मोबाईल रिचार्ज (Mobile Recharge)
                                </li>
                                <li className="flex items-center gap-2">
                                  <span className="text-red-500 text-sm">✴</span>
                                  डिश टी.व्ही. रिचार्ज (DTH Recharge)
                                </li>
                                <li className="flex items-center gap-2">
                                  <span className="text-red-500 text-sm">✴</span>
                                  तात्काळ मनी ट्रान्सफर (Instant Money Transfer)
                                </li>
                              </ul>
                            </div>

                            {/* Bank partners logos bar */}
                            <div className="grid grid-cols-4 gap-1.5 items-center justify-center border-t border-sky-200/50 pt-2 text-center">
                              <div className="bg-white px-1 py-0.5 rounded border border-slate-200 flex flex-col justify-center items-center h-8">
                                <span className="text-[6px] font-bold text-blue-700">SBI</span>
                                <div className="w-2.5 h-2.5 rounded-full bg-cyan-500 flex items-center justify-center text-[5px] text-white">●</div>
                              </div>
                              <div className="bg-white px-1 py-0.5 rounded border border-slate-200 flex flex-col justify-center items-center h-8">
                                <span className="text-[6px] font-bold text-red-600">Union Bank</span>
                                <div className="text-[6px] font-extrabold text-red-600 leading-none">UBI</div>
                              </div>
                              <div className="bg-white px-1 py-0.5 rounded border border-slate-200 flex flex-col justify-center items-center h-8">
                                <span className="text-[6px] font-bold text-orange-600">Central Bank</span>
                                <div className="w-2.5 h-2.5 rounded bg-orange-600"></div>
                              </div>
                              <div className="bg-white px-1 py-0.5 rounded border border-slate-200 flex flex-col justify-center items-center h-8">
                                <span className="text-[6px] font-bold text-blue-900">Maha Bank</span>
                                <span className="text-[5px] font-black text-blue-950 leading-none">BOM</span>
                              </div>
                            </div>

                            {/* Operator and mobile footer strip */}
                            <div className="bg-blue-900 text-white rounded-md py-1 px-2 flex justify-between items-center text-[8px] sm:text-[9px] font-bold">
                              <span>सौ. मंदाकिनी भरत पाटील</span>
                              <span className="bg-orange-500 px-1 py-0.5 rounded">मो. ९३२४७२०९४८</span>
                              <span>गाव - वैजाली</span>
                            </div>

                          </div>
                        </div>
                      )}
                      
                      <p className="text-[10px] text-slate-400 text-center leading-normal">
                        ★ You can upload your actual storefront photo or banner as <code className="text-orange-400">banner.jpg</code> in the root directory to replace this design!
                      </p>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="terminal-tab"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-4"
                    >
                      <div className="bg-slate-950/80 rounded-2xl p-4 border border-slate-800 font-mono text-xs text-slate-300">
                        <p className="text-blue-400 font-bold"># CSC_PORTAL_INFO</p>
                        <p className="mt-1"><span className="text-slate-500">Owner:</span> Mandakini B. Patil</p>
                        <p><span className="text-slate-500">Govt ID:</span> CSC-MAH-425409</p>
                        <p><span className="text-slate-500">HQ Address:</span> Vaijali, Shahada, MH</p>
                        <p className="mt-2 text-green-400 font-semibold">&gt; Service Integrity Verified.</p>
                      </div>

                      <div className="p-4 bg-blue-900/40 rounded-2xl border border-blue-800/60 text-left">
                        <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          Our Main Specialty
                        </h3>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          We offer state-of-the-art AEPS (Aadhaar Enabled Payment System) services. Just press your thumb on our reader and withdraw cash instantly from your Aadhaar linked bank account safely!
                        </p>
                      </div>

                      {/* Trust Stats Mini Board */}
                      <div className="grid grid-cols-2 gap-3 text-center">
                        <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
                          <p className="text-lg font-extrabold text-orange-400 leading-none">15,000+</p>
                          <p className="text-[10px] text-slate-400 mt-1 uppercase font-semibold">Transactions Done</p>
                        </div>
                        <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
                          <p className="text-lg font-extrabold text-white leading-none">100%</p>
                          <p className="text-[10px] text-slate-400 mt-1 uppercase font-semibold">Security Track</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4. ABOUT US SECTION */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Image with decorative frame */}
            <div className="lg:col-span-5 relative group">
              <div className="absolute -inset-4 bg-gradient-to-tr from-blue-900/10 to-orange-500/10 rounded-2xl -rotate-1 pointer-events-none" />
              <div className="absolute inset-0 border-2 border-slate-100 rounded-2xl translate-x-3 translate-y-3 pointer-events-none transition-transform group-hover:translate-x-1 group-hover:translate-y-1" />
              
              <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-blue-900 to-slate-900 shadow-xl border border-slate-200 h-[400px] flex flex-col justify-between p-6">
                {ownerPhotoExists ? (
                  <img 
                    src="/owner.jpg" 
                    alt="Mandakini Bharat Patil - Owner of Shri Swami Samarth CSC" 
                    className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105 animate-fade-in"
                    onError={() => setOwnerPhotoExists(false)}
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col justify-center items-center bg-gradient-to-tr from-blue-950 via-slate-900 to-blue-900 p-8 text-center text-white">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-orange-500 to-amber-400 flex items-center justify-center text-white text-3xl font-extrabold shadow-lg border-2 border-white/20 mb-4 tracking-tight">
                      MBP
                    </div>
                    <h3 className="text-xl font-bold tracking-tight text-white mb-1">Mandakini Bharat Patil</h3>
                    <p className="text-xs text-orange-400 font-medium tracking-wider uppercase mb-6">Founder & Authorized Operator</p>
                    
                    <div className="bg-white/5 border border-white/10 rounded-xl p-3 max-w-sm text-xs text-slate-300 leading-normal">
                      <p className="font-semibold text-blue-300 mb-1">Authorized CSC Center Owner</p>
                      <p>Serving citizens of Post Vaijali, Taluka Shahada, District Nandurbar since 2022.</p>
                    </div>
                    
                    <span className="text-[10px] text-slate-500 mt-6 block">Photo path: /owner.jpg</span>
                  </div>
                )}
                
                {/* Trust Badge Overlay */}
                <div className="absolute bottom-4 left-4 right-4 bg-blue-900/90 text-white backdrop-blur-sm p-4 rounded-xl border border-white/10 shadow-lg z-10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white shrink-0 font-bold">
                      MBP
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Mandakini Bharat Patil</h4>
                      <p className="text-xs text-orange-400 font-medium">Founder & Authorized Operator</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Narrative */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold uppercase tracking-wider">
                Our Heritage & Trust
              </div>
              
              <h2 className="text-3xl sm:text-4xl font-extrabold text-blue-950 font-display tracking-tight">
                Serving Vaijali Citizens with Transparency and Excellence
              </h2>

              <p className="text-slate-600 text-base leading-relaxed">
                Shri Swami Samarth CSC Center has been providing highly reliable digital and government-integrated services since 2022. Headquartered at Vaijali, Shahada, we are dedicated to bridging the digital divide for local citizens. 
              </p>

              <p className="text-slate-600 text-base leading-relaxed">
                We assist local residents with biometric cash withdrawals (AEPS), secure money transfers, official Aadhaar down-printing, new PAN Card applications, direct scholarship filings, and online registrations for various national and state government schemes (such as Ayushman Bharat and PM Kisan). Our mission is clear: delivering secure, transparent, and prompt service with absolute client confidentiality.
              </p>

              {/* Specific features checklist */}
              <div className="grid sm:grid-cols-2 gap-4 pt-2">
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-700 font-semibold">Government Authorized Digital Center</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-700 font-semibold">Instant AEPS Withdrawals</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-700 font-semibold">Experienced Form Filing Specialist</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-700 font-semibold">Standard Authorized CSC Fee Rates</span>
                </div>
              </div>

              {/* Quote box */}
              <div className="border-l-4 border-orange-500 bg-slate-50 p-4 rounded-r-xl">
                <p className="text-xs italic text-slate-500">
                  "At Shri Swami Samarth CSC Center, we take immense pride in ensuring that banking, documentation, and benefit transfers are accessible to every citizen in and around Vaijali. Your satisfaction is our primary reward."
                </p>
                <p className="text-xs font-bold text-blue-900 mt-2 text-right">
                  — Mandakini Bharat Patil
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. SERVICES SECTION WITH INTEGRATED LIVE FILTER */}
      <section id="services" className="py-20 bg-slate-50 border-t border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div className="text-left">
              <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2">
                Citizen Portal
              </span>
              <h2 className="text-3xl font-extrabold text-blue-950 tracking-tight font-display">
                Our Digital Services
              </h2>
              <p className="text-slate-500 text-sm mt-1 max-w-xl">
                Search or filter through our complete government-authorized service directory. Complete and correct documentation processed instantly.
              </p>
            </div>
            
            {/* Live Search */}
            <div className="relative w-full md:w-80 shrink-0">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </span>
              <input
                type="text"
                placeholder="Search services (e.g. PAN, AEPS, print)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="block w-full pl-9 pr-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-sm bg-white shadow-sm"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Service Tabs */}
          <div className="flex flex-wrap gap-2 mb-8 border-b border-slate-200 pb-4">
            {[
              { id: "all", label: "All Services" },
              { id: "banking", label: "Banking & AEPS" },
              { id: "aadhaar", label: "Aadhaar Download" },
              { id: "govt_schemes", label: "Govt. Schemes" },
              { id: "forms", label: "Online Forms & PAN" },
              { id: "printing", label: "Xerox & Photo" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? "bg-blue-900 text-white shadow-md"
                    : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Service Cards Grid */}
          {filteredServices.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredServices.map((service) => (
                <div 
                  key={service.id} 
                  className={`bg-white rounded-2xl border transition-all duration-300 flex flex-col justify-between hover:-translate-y-1 hover:shadow-lg ${
                    service.isPopular 
                      ? "border-blue-300 ring-2 ring-blue-500/10 shadow-sm shadow-blue-500/5" 
                      : "border-slate-200 shadow-xs"
                  }`}
                >
                  <div className="p-6 text-left">
                    {/* Icon and Badge Header */}
                    <div className="flex justify-between items-start mb-4">
                      {renderServiceIcon(service.icon)}
                      
                      {service.isPopular && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-blue-100 text-blue-800 tracking-wider animate-pulse">
                          Most Popular
                        </span>
                      )}
                      
                      {service.id === "aadhaar_download" && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-amber-100 text-amber-800 tracking-wider">
                          Download Only
                        </span>
                      )}
                    </div>

                    <h3 className="text-lg font-bold text-blue-950 mb-2">
                      {service.title}
                    </h3>
                    
                    <p className="text-slate-500 text-xs leading-relaxed mb-4">
                      {service.description}
                    </p>

                    {/* Highlights bullet points */}
                    {service.highlights && (
                      <ul className="space-y-1.5 border-t border-slate-100 pt-3">
                        {service.highlights.map((hl, idx) => (
                          <li key={idx} className="flex items-center gap-2 text-[11px] text-slate-600 font-medium">
                            <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
                            <span>{hl}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  {/* Card Action Link */}
                  <div className="bg-slate-50 px-6 py-4 rounded-b-2xl border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      Secured by CSC
                    </span>
                    <a 
                      href={`https://wa.me/919324720948?text=Hello%20Shri%20Swami%20Samarth%20CSC%20Center,%20I%20want%20to%20enquire%20about%20your%20service:%20${encodeURIComponent(service.title)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-bold text-blue-700 hover:text-blue-900 inline-flex items-center gap-1 transition-colors"
                    >
                      Enquire Now
                      <ArrowRight className="w-3.5 h-3.5" />
                    </a>
                  </div>

                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto">
              <Search className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-800">No Services Found</h3>
              <p className="text-slate-500 text-xs mt-1">
                We couldn't find any services matching "{searchQuery}". Try browsing all services instead.
              </p>
              <button 
                onClick={() => { setSearchQuery(""); setActiveTab("all"); }}
                className="mt-4 px-4 py-2 rounded-xl bg-blue-900 text-white text-xs font-bold hover:bg-blue-850"
              >
                Clear Filters
              </button>
            </div>
          )}

          {/* Quick Notice Banner below services */}
          <div className="mt-12 p-4 bg-orange-50 border border-orange-200 rounded-2xl text-left flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex gap-3 items-start">
              <span className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 shrink-0 mt-0.5 font-bold">!</span>
              <div>
                <p className="text-xs font-bold text-orange-950">Important Local Seva Notice</p>
                <p className="text-[11px] text-orange-900 leading-normal">
                  We provide authorized portal printing, scheme online registrations, and biometric money transfers. Please carry your physical Aadhaar card and registered mobile for E-KYC processes.
                </p>
              </div>
            </div>
            <a 
              href="#contact" 
              className="text-xs font-bold text-orange-800 hover:text-orange-950 shrink-0 underline decoration-2 underline-offset-4"
            >
              Contact Location Info
            </a>
          </div>

        </div>
      </section>

      {/* 6. WHY CHOOSE US SECTION */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="inline-flex items-center gap-1 bg-orange-100 text-orange-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2">
              Why Choose Us
            </span>
            <h2 className="text-3xl font-extrabold text-blue-950 tracking-tight font-display">
              Unmatched Trust & Seamless Experience
            </h2>
            <p className="text-slate-500 text-sm mt-2">
              Providing government verified and fast banking assistance to the citizens of Vaijali and nearby rural areas.
            </p>
          </div>

          {/* Feature Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Instant AEPS Withdrawal",
                desc: "Get your money in seconds with secure biometric authorization. No ATM cards needed.",
                icon: "⚡",
                bg: "bg-amber-50 text-amber-600"
              },
              {
                title: "Secure Transactions",
                desc: "Authorized CSC protocols ensure all personal information is heavily guarded.",
                icon: "🔒",
                bg: "bg-blue-50 text-blue-600"
              },
              {
                title: "Fast Printing",
                desc: "State-of-the-art laser printers and lamination machine for perfect documents.",
                icon: "🖨️",
                bg: "bg-green-50 text-green-600"
              },
              {
                title: "Authorized Center",
                desc: "Official service center delivering verified schemes and certificate support since 2022.",
                icon: "🏢",
                bg: "bg-purple-50 text-purple-600"
              },
              {
                title: "Digital Payments Accepted",
                desc: "Pay easily using UPI, PhonePe, GPay, Paytm, or scanned card methods.",
                icon: "📱",
                bg: "bg-pink-50 text-pink-600"
              },
              {
                title: "Trusted Local Service",
                desc: "Over 4+ years of dedicated assistance providing citizen empowerment locally.",
                icon: "🤝",
                bg: "bg-emerald-50 text-emerald-600"
              },
              {
                title: "Friendly Customer Support",
                desc: " tai provides patient, clear instructions for elders and student application processes.",
                icon: "👩",
                bg: "bg-sky-50 text-sky-600"
              },
              {
                title: "Quick Processing",
                desc: "No long queues or unnecessary wait times. Instant slip printout on every transaction.",
                icon: "🎯",
                bg: "bg-red-50 text-red-600"
              }
            ].map((feat, idx) => (
              <div 
                key={idx} 
                className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-left hover:bg-white hover:border-slate-200 hover:shadow-md transition-all group"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold mb-4 ${feat.bg}`}>
                  {feat.icon}
                </div>
                <h3 className="text-base font-bold text-blue-950 mb-1 group-hover:text-blue-900 transition-colors">
                  {feat.title}
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            ))}
          </div>

          {/* TESTIMONIAL SLIDER COOPERATION */}
          <div className="mt-16 bg-blue-900 text-white rounded-3xl p-8 lg:p-12 relative overflow-hidden shadow-xl">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-orange-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="max-w-3xl mx-auto text-center relative z-10 space-y-6">
              <span className="text-[10px] bg-orange-500 text-white px-2.5 py-1 rounded-full uppercase tracking-wider font-extrabold">
                Citizen Testimonials
              </span>

              {/* Slider content */}
              <div className="min-h-[180px] flex flex-col justify-center overflow-hidden relative">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentReviewIndex}
                    initial={{ opacity: 0, x: 40 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -40 }}
                    transition={{ type: "spring", stiffness: 150, damping: 20 }}
                    className="flex flex-col items-center justify-center w-full"
                  >
                    <div className="flex justify-center gap-1 mb-4">
                      {[...Array(reviews[currentReviewIndex].rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    
                    <p className="text-base sm:text-lg md:text-xl font-medium italic leading-relaxed text-blue-100 max-w-2xl mx-auto">
                      "{reviews[currentReviewIndex].text}"
                    </p>
                    
                    <div className="mt-4">
                      <p className="text-sm font-bold text-white">{reviews[currentReviewIndex].name}</p>
                      <p className="text-xs text-blue-300 font-medium">{reviews[currentReviewIndex].role} • {reviews[currentReviewIndex].date}</p>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-3 pt-2">
                <button 
                  onClick={() => setCurrentReviewIndex((prev) => (prev - 1 + reviews.length) % reviews.length)}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
                  aria-label="Previous review"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                
                <div className="flex gap-1.5">
                  {reviews.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentReviewIndex(idx)}
                      className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                        currentReviewIndex === idx ? "bg-orange-400 w-5" : "bg-white/30 hover:bg-white/50"
                      }`}
                      aria-label={`Go to slide ${idx + 1}`}
                    />
                  ))}
                </div>

                <button 
                  onClick={() => setCurrentReviewIndex((prev) => (prev + 1) % reviews.length)}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
                  aria-label="Next review"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

            </div>
          </div>

        </div>
      </section>



      {/* 8. WORKING HOURS & CONTACT SECTION WITH FEEDBACK FORM */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid lg:grid-cols-12 gap-12">
            
            {/* Left Column: Info Cards & Hours & Map */}
            <div className="lg:col-span-5 space-y-6 text-left">
              <div>
                <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2">
                  Find & Reach Us
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-blue-950 tracking-tight font-display">
                  Get In Touch
                </h2>
                <p className="text-slate-500 text-xs mt-1">
                  We are conveniently situated in Vaijali, Shahada. Drop by, give us a call, or write on WhatsApp directly.
                </p>
              </div>

              {/* Working Hours Block */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-blue-950 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-orange-500" />
                    Working Hours
                  </h3>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded ${isOpenNow ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                    {isOpenNow ? "OPEN NOW" : "CLOSED NOW"}
                  </span>
                </div>
                
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center py-1.5 border-b border-slate-200">
                    <span className="font-semibold text-slate-700">Physical Center (Daily)</span>
                    <span className="text-slate-600 font-bold">9:00 AM – 7:00 PM (Monday to Sunday)</span>
                  </div>
                  <div className="flex justify-between items-center py-1.5 text-green-600">
                    <span className="font-semibold">Digital Support & Enquiries</span>
                    <span className="font-extrabold uppercase tracking-wider text-[10px] bg-green-50 px-2 py-0.5 rounded border border-green-200">24x7 Open</span>
                  </div>
                </div>
              </div>

              {/* Direct Info list */}
              <div className="space-y-3">
                <a 
                  href="tel:9324720948" 
                  className="flex items-start gap-3 bg-slate-50/50 hover:bg-slate-50 p-4 rounded-xl border border-slate-100 transition-colors"
                >
                  <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Phone Number</p>
                    <p className="text-sm font-bold text-slate-800">9324720948</p>
                  </div>
                </a>

                <a 
                  href="https://wa.me/919324720948?text=Hello%20Shri%20Swami%20Samarth%20CSC%20Center." 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 bg-slate-50/50 hover:bg-slate-50 p-4 rounded-xl border border-slate-100 transition-colors"
                >
                  <div className="w-9 h-9 rounded-lg bg-green-100 flex items-center justify-center text-green-600 shrink-0">
                    <MessageSquare className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">WhatsApp Operator</p>
                    <p className="text-sm font-bold text-slate-800">9324720948 (Instant Response)</p>
                  </div>
                </a>

                <a 
                  href="mailto:travelways000@gmail.com" 
                  className="flex items-start gap-3 bg-slate-50/50 hover:bg-slate-50 p-4 rounded-xl border border-slate-100 transition-colors"
                >
                  <div className="w-9 h-9 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Email Enquiries</p>
                    <p className="text-sm font-bold text-slate-800 truncate">travelways000@gmail.com</p>
                  </div>
                </a>

                <div className="flex items-start gap-3 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                  <div className="w-9 h-9 rounded-lg bg-orange-100 flex items-center justify-center text-orange-600 shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Registered Address</p>
                    <p className="text-xs font-bold text-slate-800 leading-normal">
                      At Post Vaijali, Taluka Shahada, District Nandurbar, Maharashtra, India
                    </p>
                  </div>
                </div>
              </div>

              {/* Styled Maps Trigger block with Coordinates representation */}
              <div className="bg-slate-900 text-white rounded-2xl p-5 relative overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/[0.02] pointer-events-none" />
                <div className="relative z-10 flex flex-col justify-between h-full">
                  <div>
                    <span className="text-[9px] bg-orange-500 px-2 py-0.5 rounded font-black uppercase">Live Location Coordinates</span>
                    <h4 className="text-sm font-extrabold text-white mt-1.5">H9G7+J2X, Vaijaly, Maharashtra</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-normal">
                      Visit us directly in Vaijali town. Our authorized CSC center is equipped with a digital services kiosk banner outside.
                    </p>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <a 
                      href="https://www.google.com/maps/search/?api=1&query=H9G7%2BJ2X+Vaijaly+Maharashtra"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-white text-slate-900 text-xs font-bold px-4 py-2 rounded-xl hover:bg-slate-100 transition-colors inline-flex items-center gap-1 cursor-pointer"
                    >
                      <MapPin className="w-3.5 h-3.5 text-orange-500" />
                      Get Directions
                    </a>
                    <a 
                      href="https://www.google.com/maps/search/?api=1&query=Shri+Swami+Samarth+CSC+Center+Vaijali"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 text-xs font-semibold px-4 py-2 rounded-xl transition-colors inline-flex items-center gap-1 cursor-pointer"
                    >
                      Search Google Maps
                      <ExternalLink className="w-3 h-3 text-slate-400" />
                    </a>
                  </div>
                </div>
              </div>

            </div>

            {/* Right Column: Citizen Feedback & Enquiry Form */}
            <div className="lg:col-span-7">
              <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-8 relative">
                
                <div className="absolute top-4 right-4">
                  <button 
                    onClick={() => {
                      setIsAdminMode(!isAdminMode);
                      setAdminAccessGranted(false);
                      setAdminPassword("");
                      setAdminError("");
                    }}
                    className="p-1.5 rounded-lg bg-slate-200 text-slate-500 hover:text-slate-800 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    title="CSC Owner Portal Login"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    {isAdminMode ? "Exit Admin" : "Admin Logs"}
                  </button>
                </div>

                {/* DYNAMIC VIEW SWITCHING: Standard Enquiry Form VS Admin Submissions Dashboard */}
                {!isAdminMode ? (
                  <div className="text-left space-y-4">
                    <div>
                      <h3 className="text-xl font-bold text-blue-950 font-display">
                        Citizen Feedback & Inquiry Form
                      </h3>
                      <p className="text-slate-500 text-xs mt-1">
                        Have questions about documents needed or scheme registration? Submit details below, and we will get back to you immediately!
                      </p>
                    </div>

                    {formSubmitted ? (
                      <div className="bg-green-500/10 border border-green-500/20 text-green-900 rounded-2xl p-6 space-y-4 text-center">
                        <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 mx-auto">
                          <CheckCircle2 className="w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="text-base font-bold text-green-950">
                            Enquiry Logged Successfully!
                          </h4>
                          <p className="text-xs text-green-800 mt-1">
                            "Thank you for contacting Shri Swami Samarth CSC Center."
                          </p>
                          <p className="text-[11px] text-green-700 mt-2 max-w-md mx-auto">
                            Mandakini B. Patil is notified. You can also click the quick compose email option below to draft an official email directly to our inbox.
                          </p>
                        </div>
                        <div className="pt-2 flex flex-col sm:flex-row justify-center gap-2">
                          <a 
                            href={`mailto:travelways000@gmail.com?subject=Enquiry%20from%20${encodeURIComponent(formData.fullName)}&body=Name:%20${encodeURIComponent(formData.fullName)}%0AMobile:%20${encodeURIComponent(formData.mobile)}%0AMessage:%20${encodeURIComponent(formData.message)}`}
                            className="bg-green-600 text-white font-bold px-4 py-2 rounded-xl text-xs hover:bg-green-700 transition-colors inline-flex items-center justify-center gap-1.5"
                          >
                            <Mail className="w-4 h-4" />
                            Send Direct Email
                          </a>
                          <button 
                            onClick={resetForm}
                            className="bg-slate-200 text-slate-800 font-semibold px-4 py-2 rounded-xl text-xs hover:bg-slate-300 transition-colors"
                          >
                            Submit Another Inquiry
                          </button>
                        </div>
                      </div>
                    ) : (
                      <form onSubmit={handleFormSubmit} className="space-y-4">
                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label htmlFor="fullName" className="block text-xs font-bold text-slate-700 uppercase">
                              Full Name <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="text"
                              id="fullName"
                              name="fullName"
                              required
                              placeholder="Enter your full name"
                              value={formData.fullName}
                              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                              className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-white"
                            />
                          </div>

                          <div className="space-y-1">
                            <label htmlFor="mobile" className="block text-xs font-bold text-slate-700 uppercase">
                              Mobile Number <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="tel"
                              id="mobile"
                              name="mobile"
                              required
                              placeholder="Enter 10-digit mobile"
                              pattern="[0-9]{10}"
                              value={formData.mobile}
                              onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                              className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-white"
                            />
                          </div>
                        </div>

                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label htmlFor="email" className="block text-xs font-bold text-slate-700 uppercase">
                              Email Address
                            </label>
                            <input
                              type="email"
                              id="email"
                              name="email"
                              placeholder="yourname@gmail.com"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                              className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-white"
                            />
                          </div>

                          <div className="space-y-1">
                            <label htmlFor="subject" className="block text-xs font-bold text-slate-700 uppercase">
                              Subject / Enquiry Topic
                            </label>
                            <select
                              id="subject"
                              name="subject"
                              value={formData.subject}
                              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                              className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-white"
                            >
                              <option value="">-- Choose Topic --</option>
                              <option value="Aadhaar Enquiry">Aadhaar Verification / Download</option>
                              <option value="AEPS Banking">AEPS Cash Withdrawal Inquiry</option>
                              <option value="PAN Card Services">New PAN / Corrections</option>
                              <option value="Government Schemes">PM Kisan / Ayushman Bharat</option>
                              <option value="Scholarship Application">Mahadbt Scholarship Support</option>
                              <option value="Xerox & Photos">Bulk Photocopy / Passport Photos</option>
                              <option value="General Support">Other Digital Seva Queries</option>
                            </select>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label htmlFor="message" className="block text-xs font-bold text-slate-700 uppercase">
                            Message <span className="text-red-500">*</span>
                          </label>
                          <textarea
                            id="message"
                            name="message"
                            required
                            rows={4}
                            placeholder="Briefly explain your query here. e.g. What documents are needed for my PAN correction?"
                            value={formData.message}
                            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                            className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-white"
                          />
                        </div>

                        <div className="pt-2">
                          <button
                            type="submit"
                            id="submit-feedback-btn"
                            className="w-full bg-blue-900 hover:bg-blue-850 text-white font-extrabold py-3 px-6 rounded-2xl shadow-lg hover:shadow-blue-900/10 transition-all text-xs flex items-center justify-center gap-2 cursor-pointer"
                          >
                            <Mail className="w-4 h-4" />
                            Submit Inquiry to travelways000@gmail.com
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                ) : (
                  /* EXTREMELY PREMIUM INTERNAL ADMIN DASHBOARD FOR VIEWING FORM LEADS */
                  <div className="text-left space-y-4">
                    <div>
                      <h3 className="text-xl font-bold text-orange-950 font-display flex items-center gap-2">
                        <Lock className="w-5 h-5 text-orange-600 animate-pulse" />
                        CSC Secure Citizen Portal Log
                      </h3>
                      <p className="text-slate-500 text-xs mt-1">
                        Private log window to let the center manager track all citizen inquiry logs directly saved in localStorage.
                      </p>
                    </div>

                    {!adminAccessGranted ? (
                      <form onSubmit={handleAdminAuth} className="bg-slate-100 p-5 rounded-2xl border border-slate-200 space-y-4">
                        <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                          🔐 Enter the secure 10-digit Portal Access PIN to view and manage citizen inquiries.
                        </p>
                        <div className="flex gap-2">
                          <input
                            type="password"
                            placeholder="Enter secure 10-digit PIN"
                            value={adminPassword}
                            onChange={(e) => setAdminPassword(e.target.value)}
                            className="flex-1 px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-white"
                          />
                          <button
                            type="submit"
                            className="bg-blue-900 hover:bg-blue-850 text-white font-bold px-4 py-2 rounded-xl text-xs cursor-pointer transition-colors"
                          >
                            Verify PIN
                          </button>
                        </div>
                        {adminError && <p className="text-xs text-red-600 font-bold">{adminError}</p>}
                      </form>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center bg-blue-100/60 p-3 rounded-xl border border-blue-200">
                          <span className="text-xs text-blue-900 font-bold">
                            Total Received Inquiries: {feedbackList.length}
                          </span>
                          <button 
                            onClick={() => setAdminAccessGranted(false)}
                            className="text-xs text-slate-600 hover:text-slate-800 font-bold"
                          >
                            Lock Database
                          </button>
                        </div>

                        {feedbackList.length > 0 ? (
                          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                            {feedbackList.map((feedback) => (
                              <div 
                                key={feedback.id} 
                                className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs relative text-xs"
                              >
                                <button 
                                  onClick={() => deleteFeedback(feedback.id)}
                                  className="absolute top-3 right-3 text-red-500 hover:text-red-700 p-1 rounded-lg hover:bg-red-50 transition-colors"
                                  title="Delete message from local storage logs"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                                
                                <div className="space-y-1 max-w-[90%]">
                                  <p className="font-bold text-slate-800 flex items-center gap-1.5">
                                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                                    {feedback.fullName} 
                                    <span className="text-[10px] font-normal text-slate-400">({feedback.date})</span>
                                  </p>
                                  <p className="text-[11px] text-slate-500">
                                    <span className="font-semibold text-slate-600">Mobile:</span> {feedback.mobile} | <span className="font-semibold text-slate-600">Email:</span> {feedback.email}
                                  </p>
                                  <p className="text-[11px] text-slate-600 font-bold">
                                    <span className="font-semibold text-slate-400">Topic:</span> {feedback.subject}
                                  </p>
                                  <p className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg italic border-l-2 border-orange-400 mt-1.5 leading-normal">
                                    "{feedback.message}"
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="bg-white p-8 rounded-xl border border-slate-200 text-center">
                            <p className="text-xs text-slate-500 font-medium">No customer inquiries logged yet.</p>
                          </div>
                        )}
                        
                        <div className="text-right">
                          <button 
                            onClick={() => {
                              if(window.confirm("Are you sure you want to clear all inquiries?")) {
                                setFeedbackList([]);
                                localStorage.removeItem("csc_feedback_logs");
                              }
                            }}
                            className="text-[10px] text-red-600 font-bold hover:underline"
                          >
                            Clear Logs Database
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 9. PREMIUM FOOTER */}
      <footer className="bg-slate-900 text-slate-200 border-t-4 border-orange-500 pt-16 pb-8 text-left">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
            
            {/* Column 1: Info & Brand */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-orange-500 flex items-center justify-center text-white font-extrabold text-sm">
                  SS
                </div>
                <h3 className="text-base font-extrabold text-white tracking-tight">
                  Swami Samarth CSC
                </h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Authorized Common Service Center and AEPS Banking portal in Vaijali. Empowering rural citizens with transparent digital integrations since 2022.
              </p>
              <div className="text-xs text-slate-400 space-y-1">
                <p className="font-bold text-white">Govt. Operator ID:</p>
                <p className="font-mono text-orange-400">CSC-MAH-425409</p>
              </div>
            </div>

            {/* Column 2: Quick Navigation */}
            <div className="space-y-4">
              <h4 className="text-sm font-extrabold text-white tracking-wide uppercase">
                Quick Navigation
              </h4>
              <ul className="space-y-2 text-xs font-semibold">
                <li>
                  <a href="#about" className="text-slate-400 hover:text-white transition-colors">
                    About Our Center
                  </a>
                </li>
                <li>
                  <a href="#services" className="text-slate-400 hover:text-white transition-colors">
                    Search Digital Services
                  </a>
                </li>
                <li>
                  <a href="#features" className="text-slate-400 hover:text-white transition-colors">
                    Why Citizens Choose Us
                  </a>
                </li>
                <li>
                  <a href="#contact" className="text-slate-400 hover:text-white transition-colors">
                    Find Location & Map
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 3: Contact & Address */}
            <div className="space-y-4">
              <h4 className="text-sm font-extrabold text-white tracking-wide uppercase">
                Official Address
              </h4>
              <p className="text-xs text-slate-400 leading-normal">
                Shri Swami Samarth CSC Center <br />
                At Post Vaijali, Taluka Shahada, <br />
                District Nandurbar, Maharashtra, India.
              </p>
              <p className="text-xs text-slate-400">
                <span className="font-bold text-white">Mobile:</span> 9324720948 <br />
                <span className="font-bold text-white">WhatsApp:</span> 9324720948
              </p>
            </div>

            {/* Column 4: Legal & Standard Guidelines */}
            <div className="space-y-4">
              <h4 className="text-sm font-extrabold text-white tracking-wide uppercase">
                Legal & Governance
              </h4>
              <ul className="space-y-2 text-xs font-semibold">
                <li>
                  <button 
                    onClick={() => setActiveModal("privacy")}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer block text-left"
                  >
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveModal("terms")}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer block text-left"
                  >
                    Terms & Conditions
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setActiveModal("disclaimer")}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer block text-left"
                  >
                    CSC Operator Disclaimer
                  </button>
                </li>
              </ul>
              <div className="pt-2 border-t border-slate-800">
                <p className="text-[10px] text-slate-500 leading-normal">
                  Our services are offered as per standardized rates published by the National CSC Grid, Govt. of India.
                </p>
              </div>
            </div>

          </div>

          <hr className="border-slate-800 my-10" />

          {/* Copyright Grid */}
          <div className="flex flex-col md:flex-row justify-between items-center text-xs text-slate-500 gap-4">
            <div className="text-center md:text-left">
              <p>© 2025 Shri Swami Samarth CSC Center. All Rights Reserved.</p>
              <p className="mt-1 text-[10px] text-slate-600">
                Designed & Optimized for local search algorithms in Vaijali, Shahada, Maharashtra.
              </p>
            </div>
            <div className="flex items-center gap-4 text-[10px]">
              <span>Operator: Mandakini Bharat Patil</span>
              <span>•</span>
              <span>Estd. 2022</span>
            </div>
          </div>

        </div>
      </footer>

      {/* 10. MODAL POPUPS (PRIVACY, TERMS, DISCLAIMER) */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl max-h-[85vh] overflow-y-auto text-left border border-slate-200">
            
            {/* Close */}
            <button 
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-600 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Privacy Policy */}
            {activeModal === "privacy" && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-blue-900">
                  <ShieldCheck className="w-6 h-6 text-orange-500" />
                  <h3 className="text-xl font-bold font-display">Privacy Policy</h3>
                </div>
                <p className="text-[11px] text-slate-400 font-mono">Last Updated: July 2026</p>
                <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
                  <p>
                    At **Shri Swami Samarth CSC Center**, operating in Vaijali, Maharashtra, we are committed to upholding the privacy and security of every citizen's personal data. 
                  </p>
                  <p className="font-semibold text-slate-800">1. Data Storage & Purging</p>
                  <p>
                    We do not store or mirror your personal biometric templates, Aadhaar numbers, or banking PINs. All financial and biometric cash withdrawal processing is handled directly via authorized NPCI gateways.
                  </p>
                  <p className="font-semibold text-slate-800">2. Official Documents Handling</p>
                  <p>
                    When you request an E-Aadhaar download, PAN Card correction, or scholarship file download, the files retrieved are exclusively printed for you and immediately deleted from our terminal post-print. No copy remains stored in our local computer.
                  </p>
                  <p className="font-semibold text-slate-800">3. Local Inquiries</p>
                  <p>
                    Information submitted through our online citizen feedback form (such as name and mobile number) is used solely to respond to your specific enquiry. It is never sold, shared, or compiled for marketing.
                  </p>
                </div>
              </div>
            )}

            {/* Terms & Conditions */}
            {activeModal === "terms" && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-blue-900">
                  <FileText className="w-6 h-6 text-orange-500" />
                  <h3 className="text-xl font-bold font-display">Terms & Conditions</h3>
                </div>
                <p className="text-[11px] text-slate-400 font-mono">Last Updated: July 2026</p>
                <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
                  <p>
                    By accessing services from **Shri Swami Samarth CSC Center**, citizens of Vaijali and online visitors agree to abide by the following terms of operation:
                  </p>
                  <p className="font-semibold text-slate-800">1. Rate Agreement</p>
                  <p>
                    All charges for government scheme filings, recharges, printing, scanning, and digital applications adhere strictly to authorized rates declared by the Government of India CSC Grid. Standard list prices are clearly updated on our local notice boards.
                  </p>
                  <p className="font-semibold text-slate-800">2. Biometric Verification</p>
                  <p>
                    To withdraw cash through Aadhaar Enabled Payment System (AEPS), you must be present in person to place your registered fingerprint on our authorized scanner. We do not support proxy transactions.
                  </p>
                  <p className="font-semibold text-slate-800">3. Verification of Information</p>
                  <p>
                    Citizens are responsible for providing correct personal documents (Aadhaar, income certificates, caste details) for scholarship and scheme registrations. The operator is not liable for form rejections resulting from incorrect submissions.
                  </p>
                </div>
              </div>
            )}

            {/* Disclaimer */}
            {activeModal === "disclaimer" && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-blue-900">
                  <Award className="w-6 h-6 text-orange-500" />
                  <h3 className="text-xl font-bold font-display">CSC Operator Disclaimer</h3>
                </div>
                <p className="text-[11px] text-slate-400 font-mono">Last Updated: July 2026</p>
                <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
                  <p>
                    **Shri Swami Samarth CSC Center** is an independently operated Common Service Center directed by Mandakini Bharat Patil, registered in the state of Maharashtra. 
                  </p>
                  <p className="font-semibold text-slate-800">1. Not a Government Agency</p>
                  <p>
                    While we are an authorized government service provider and facilitator, we are not a government office. We serve as an intermediary service hub enabling local rural residents to access various public portals and banking utilities cleanly.
                  </p>
                  <p className="font-semibold text-slate-800">2. Biometric Corrections Limitations</p>
                  <p>
                    We provide official **Aadhaar Download & Reprint only**. We are not a UIDAI Demographic Update Center. Biometric additions, iris scans, or demographic corrections must be physically resolved by visiting an official Aadhaar Seva Kendra at the Shahada headquarters or authorized banks.
                  </p>
                  <p className="font-semibold text-slate-800">3. Transaction Failures</p>
                  <p>
                    In rare cases of AEPS cash withdrawal failure where funds are deducted from your bank but not disbursed at our terminal, the resolution remains governed strictly by bank dispute channels (typically settled within 3 to 7 working days by your bank).
                  </p>
                </div>
              </div>
            )}

            {/* Modal Footer */}
            <div className="mt-6 pt-4 border-t border-slate-200 text-right">
              <button 
                onClick={() => setActiveModal(null)}
                className="bg-blue-900 text-white font-bold px-5 py-2.5 rounded-xl text-xs hover:bg-blue-850 transition-colors cursor-pointer"
              >
                I Understand & Accept
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
